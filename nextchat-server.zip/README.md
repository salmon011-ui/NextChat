# NextChat Server

Bu — NextChat ilovasining **haqiqiy backend serveri**. Endi ma'lumotlar (foydalanuvchilar, xabarlar, guruhlar) bitta telefon xotirasida emas, shu serverda saqlanadi, shuning uchun ikki xil telefon internet orqali bir-biriga yozishi va qo'ng'iroq qilishi mumkin.

## 1) Kompyuteringizda sinab ko'rish

```
npm install
node server.js
```

Server `http://localhost:3000` da ishga tushadi. Brauzerda shu manzilni oching.

Agar ikkita telefonni **shu bir xil Wi-Fi tarmog'ida** sinab ko'rmoqchi bo'lsangiz:
- Kompyuteringizning lokal IP manzilini toping (masalan `192.168.1.5`)
- Telefon brauzerida `http://192.168.1.5:3000` manzilini oching

Bu variant faqat bir xil Wi-Fi tarmog'ida ishlaydi — turli joylardagi (mobil internetdagi) telefonlar uchun serverni internetga chiqarish kerak (2-bo'lim).

## 2) Internetga chiqarish (istalgan joydan ishlashi uchun)

Eng oson bepul variantlardan biri — **Render.com**:

1. https://render.com saytida ro'yxatdan o'ting.
2. "New +" → "Web Service" tanlang.
3. Bu papkani (yoki GitHub repo qilib) yuklang.
4. Sozlamalar:
   - Build Command: `npm install`
   - Start Command: `node server.js`
5. Deploy qiling — sizga `https://sizning-nom.onrender.com` kabi doimiy internet manzili beriladi.
6. Shu manzilni ikkala telefonda ham oching, ro'yxatdan o'ting va gaplashishni boshlang.

Railway.app yoki Fly.io ham xuddi shunday ishlaydi.

## 3) Telefonga "ilova" sifatida o'rnatish

Manzilni telefon brauzerida oching → menyu → **"Bosh ekranga qo'shish" (Add to Home Screen)**. Shundan keyin oddiy ilova kabi ikonka orqali ochiladi.

## 4) Muhim eslatmalar

- **Qo'ng'iroqlar** endi haqiqiy WebRTC orqali ishlaydi — ikkinchi telefonning chinakam kamerasi/ovozi keladi (avvalgi "demo" versiyadan farqli).
- Ba'zi mobil internet tarmoqlari (ayniqsa operatorlar NAT'i qattiq bo'lsa) uchun bepul STUN serveri yetarli bo'lmasligi mumkin — bunday holatda qo'ng'iroq ulanmasligi mumkin. Agar shunday muammo chiqsa, professional TURN server (masalan Twilio, Metered.ca) qo'shish kerak bo'ladi — kerak bo'lsa buni ham sozlab beraman.
- **Guruh qo'ng'irog'i** hozircha soddalashtirilgan (demo) rejimda — 3+ kishi orasida haqiqiy video-konferensiya (mesh yoki SFU) alohida katta ish, xohlasangiz buni ham qo'shib beraman.
- Yuklangan rasm/video/musiqa fayllari `uploads/` papkasida saqlanadi. Agar Render kabi bepul xizmatlarda server "uxlab qolsa" (uzoq vaqt ishlatilmasa), fayllar va `data/db.json' o'chib ketishi mumkin — doimiy saqlash uchun pullik reja yoki tashqi bazadan (masalan PostgreSQL) foydalanish tavsiya etiladi.
