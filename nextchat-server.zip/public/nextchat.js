// =========================================================================
// NEXTCHAT.JS - SERVERGA ULANGAN VERSIYA (1-BO'LAK: SOZLAMALAR)
// =========================================================================

let myUsername = "";
let currentChat = null;
let currentChatType = null; // 'private' | 'group'
let chatSearchQuery = "";
let activeDeleteMsgId = null;
let socket = null;

// Guruhlar keshi (tez-tez ishlatiladi)
let myGroupsCache = [];

// Ovoz/video yozish holatlari
let voiceRecorder = null, voiceChunks = [], voiceStartTime = 0, voiceTimerInterval = null, voiceRecordStream = null;
let roundVideoRecorder = null, roundVideoChunks = [], roundVideoStream = null, roundVideoTimerInterval = null, roundVideoSeconds = 0, roundVideoFinalBlob = null;

// ---- QO'NG'IROQ (HAQIQIY WebRTC) HOLATLARI ----
const RTC_CONFIG = { iceServers: [
    { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'] }
] };
let peerConnection = null;
let localStream = null;
let remoteMediaStream = null;
let currentCallPeer = null;      // suhbatdosh username (1:1)
let currentCallDirection = null; // 'outgoing' | 'incoming'
let currentCallType = 'audio';
let isCallActive = false;
let isCallMinimized = false;
let isMuted = false, isSpeakerOn = false;
let audioCtx = null, remoteGainNode = null;
let cameraFacingMode = 'user';
let isCameraOff = false;
let callTimer = null, callSeconds = 0;
let currentCallEmojiCode = "";

const CALL_CODE_EMOJIS = ["🌙", "🎃", "🔬", "🍼", "🍭", "🐮", "👑", "🍩", "🐝", "🍕", "🚀", "⚽", "🦊", "🍓", "🎮", "🌵", "🔥", "🎈", "🐟", "🍋"];

const EMOJI_CATEGORIES = [
    { title: "😊", list: ["😊", "😂", "🥰", "😘", "😜", "😎", "🤩", "😢", "😡", "😱", "👍", "👎", "🔥", "❤️"] },
    { title: "🐱", list: ["🐱", "🐶", "🦊", "🐻", "🦁", "🐯", "🐸", "🐵", "🐔", "🐧", "🐝", "🦋", "🐟", "🦈"] },
    { title: "🍏", list: ["🍏", "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🫐", "🍕", "🍔", "🍟", "🍦"] },
    { title: "⚽", list: ["⚽", "🏀", "🏈", "⚾", "🎾", "🏐", "🏉", "🎱", "🏓", "🏸", "🎮", "🕹️", "🏆", "🥇"] },
    { title: "🚗", list: ["🚗", "🚕", "🚙", "🚌", "🚎", "🏎️", "🚓", "🚑", "🚒", "🚲", "🛵", "✈️", "🚀", "🗺️"] }
];

function escapeHtml(str) {
    if (str === null || str === undefined) return "";
    return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
}

function isGroupChat(chatId) { return typeof chatId === 'string' && chatId.indexOf('grp_') === 0; }

function getDeviceId() {
    let id = localStorage.getItem('nc_device_id');
    if (!id) { id = 'dev_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9); localStorage.setItem('nc_device_id', id); }
    return id;
}

function formatDuration(sec) {
    sec = Math.round(sec || 0);
    let m = Math.floor(sec / 60).toString().padStart(2, '0');
    let s = (sec % 60).toString().padStart(2, '0');
    return m + ':' + s;
}

async function apiCall(method, url, body) {
    let opts = { method: method, headers: {} };
    if (body) { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    let res = await fetch(url, opts);
    let data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Server xatoligi");
    return data;
}

document.addEventListener("DOMContentLoaded", function() {
    setupAuthToggle();
    setupAuthAction();
    setupSearch();
    setupMessageSending();
    setupModalEvents();
    setupCallButtons();
    setupGroupFeatures();
    setupChatOptionsMenu();
    setupInChatSearch();
    setupAttachMenu();
    setupVoiceMessages();
    setupRoundVideoMessages();
    tryAutoLogin();
});

let isLoginMode = true;
function setupAuthToggle() {
    const authTitle = document.getElementById('auth-title');
    const mainAuthBtn = document.getElementById('main-auth-btn');
    const toggleAuthText = document.getElementById('toggle-auth-text');
    if (!authTitle || !mainAuthBtn || !toggleAuthText) return;

    document.body.addEventListener('click', function(e) {
        if (e.target && e.target.id === 'switch-to-reg') {
            isLoginMode = false;
            authTitle.innerText = "Ro'yxatdan o'tish";
            mainAuthBtn.innerText = "Ro'yxatdan o'tish";
            toggleAuthText.innerHTML = 'Akkountingiz bormi? <span id="switch-to-login" style="color:#5288c1;cursor:pointer;font-weight:bold;">Kirish</span>';
        }
        if (e.target && e.target.id === 'switch-to-login') {
            isLoginMode = true;
            authTitle.innerText = "Chatga kirish";
            mainAuthBtn.innerText = "Kirish";
            toggleAuthText.innerHTML = 'Akkountingiz yo\'qmi? <span id="switch-to-reg" style="color:#5288c1;cursor:pointer;font-weight:bold;">Ro\'yxatdan o\'tish</span>';
        }
    });
}

function tryAutoLogin() {
    let saved = JSON.parse(localStorage.getItem('nc_saved_login') || 'null');
    if (!saved) return;
    apiCall('POST', '/api/login', { username: saved.username, password: saved.password }).then(function(data) {
        myUsername = data.username;
        openChat();
    }).catch(function() { localStorage.removeItem('nc_saved_login'); });
}

function setupAuthAction() {
    const mainAuthBtn = document.getElementById('main-auth-btn');
    const usernameInput = document.getElementById('username-input');
    const passwordInput = document.getElementById('password-input');
    if (!mainAuthBtn || !usernameInput || !passwordInput) return;

    mainAuthBtn.addEventListener('click', async function() {
        let userVal = usernameInput.value.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
        let passVal = passwordInput.value.trim();
        if (userVal === "" || passVal === "") { alert("Iltimos, barcha maydonlarni to'ldiring!"); return; }

        try {
            if (isLoginMode) {
                let data = await apiCall('POST', '/api/login', { username: userVal, password: passVal });
                myUsername = data.username;
                localStorage.setItem('nc_saved_login', JSON.stringify({ username: userVal, password: passVal }));
                alert("Profilingizga xush kelibsiz!");
                openChat();
            } else {
                let data = await apiCall('POST', '/api/register', { username: userVal, password: passVal, deviceId: getDeviceId() });
                myUsername = data.username;
                localStorage.setItem('nc_saved_login', JSON.stringify({ username: userVal, password: passVal }));
                alert("Tabriklaymiz! Ro'yxatdan muvaffaqiyatli o'tdingiz.");
                openChat();
            }
        } catch (err) {
            alert(err.message);
        }
    });
}

function openChat() {
    const authContainer = document.getElementById('auth-container');
    const chatContainer = document.getElementById('chat-container');
    const userDisplay = document.getElementById('user-display');
    if (authContainer) authContainer.style.display = 'none';
    if (chatContainer) chatContainer.style.display = 'flex';
    if (userDisplay) userDisplay.innerText = myUsername;

    socket = io();
    socket.on('connect', function() { socket.emit('identify', myUsername); });
    setupSocketListeners();

    refreshGroupsCache().then(function() {
        window.renderActiveChats();
    });
}

async function refreshGroupsCache() {
    try {
        let data = await apiCall('GET', '/api/groups/for/' + encodeURIComponent(myUsername));
        myGroupsCache = data.groups;
    } catch (e) { /* jim */ }
}

// =========================================================================
// 2-BO'LAK: SOCKET.IO REAL VAQTLI EVENTLAR
// =========================================================================

function setupSocketListeners() {
    socket.on('message:new', function(msg) {
        let relevantToOpenChat = false;
        if (msg.chatType === 'private' && !isGroupChat(currentChat) && ((msg.sender === myUsername && msg.target === currentChat) || (msg.sender === currentChat && msg.target === myUsername))) relevantToOpenChat = true;
        if (msg.chatType === 'group' && currentChat === msg.target) relevantToOpenChat = true;

        if (relevantToOpenChat) {
            if (msg.sender !== myUsername) { markCurrentChatRead(); }
            window.loadMessages();
        }
        window.renderActiveChats();
    });

    socket.on('messages:read', function(data) {
        if (currentChat === data.by || (isGroupChat(currentChat))) window.loadMessages();
    });

    socket.on('message:deleted', function(data) {
        window.loadMessages();
    });

    socket.on('groups:updated', function() {
        refreshGroupsCache().then(function() { window.renderActiveChats(); });
    });

    // ---- QO'NG'IROQ SIGNALING EVENTLARI ----
    socket.on('call:incoming', function(data) { handleIncomingCall(data); });
    socket.on('call:accepted', function(data) { handleCallAccepted(data); });
    socket.on('call:rejected', function(data) { alert((data.from || "Foydalanuvchi") + " qo'ng'iroqni rad etdi."); closeCallWindow(); });
    socket.on('call:offer', function(data) { handleCallOffer(data); });
    socket.on('call:answer', function(data) { handleCallAnswer(data); });
    socket.on('call:ice', function(data) { handleRemoteIce(data); });
    socket.on('call:ended', function() { closeCallWindow(); });
}

function markCurrentChatRead() {
    if (!currentChat) return;
    apiCall('POST', '/api/messages/read', { me: myUsername, chatType: isGroupChat(currentChat) ? 'group' : 'private', target: currentChat }).catch(() => {});
}

// =========================================================================
// 3-BO'LAK: FOYDALANUVCHI QIDIRUV
// =========================================================================

function setupSearch() {
    const searchInput = document.getElementById('tg-search-input');
    const searchResultsList = document.getElementById('search-results-list');
    if (!searchInput || !searchResultsList) return;

    let debounceTimer = null;
    searchInput.addEventListener('input', function() {
        clearTimeout(debounceTimer);
        let queryText = searchInput.value.trim().toLowerCase();
        if (queryText === "") { searchResultsList.style.display = 'none'; return; }
        debounceTimer = setTimeout(async function() {
            searchResultsList.innerHTML = ''; searchResultsList.style.display = 'block';
            let foundAny = false;
            try {
                let data = await apiCall('GET', '/api/users/search?q=' + encodeURIComponent(queryText) + '&me=' + encodeURIComponent(myUsername));
                data.users.forEach(function(u) {
                    foundAny = true;
                    let div = document.createElement('div'); div.className = 'chat-item';
                    div.innerHTML = `<div class="chat-avatar" style="background:#5288c1;">${escapeHtml(u.substring(1,3).toUpperCase())}</div><div class="chat-info"><span class="chat-title">${escapeHtml(u)}</span></div>`;
                    div.onclick = async function() {
                        await apiCall('POST', '/api/contacts/add', { me: myUsername, target: u });
                        searchInput.value = ""; searchResultsList.style.display = 'none';
                        window.switchChat(u, 'private');
                        window.renderActiveChats();
                    };
                    searchResultsList.appendChild(div);
                });
            } catch (e) {}

            myGroupsCache.forEach(function(g) {
                if (g.name.toLowerCase().includes(queryText)) {
                    foundAny = true;
                    let div = document.createElement('div'); div.className = 'chat-item';
                    div.innerHTML = `<div class="chat-avatar group-avatar">${escapeHtml(g.name.substring(0,2).toUpperCase())}</div><div class="chat-info"><span class="chat-title">${escapeHtml(g.name)}</span></div>`;
                    div.onclick = function() { searchInput.value = ""; searchResultsList.style.display = 'none'; window.switchChat(g.id, 'group'); };
                    searchResultsList.appendChild(div);
                }
            });
            if (!foundAny) searchResultsList.innerHTML = `<div class="add-person-empty" style="padding:14px;">Hech narsa topilmadi</div>`;
        }, 250);
    });
}

// =========================================================================
// 4-BO'LAK: CHATLAR RO'YXATI VA XABARLARNI YUKLASH
// =========================================================================

function messagePreviewText(m) {
    if (!m) return "Suhbat yo'q";
    if (m.type === 'voice') return "🎤 Ovozli xabar";
    if (m.type === 'video_round') return "⏺ Video xabar";
    if (m.type === 'image') return "🖼️ Rasm";
    if (m.type === 'video') return "🎬 Video";
    if (m.type === 'audio_music') return "🎵 " + (m.fileName || "Musiqa");
    return m.text;
}

window.renderActiveChats = async function() {
    const chatsListMain = document.getElementById('chats-list-main'); if (!chatsListMain) return;
    let data;
    try { data = await apiCall('GET', '/api/chats/' + encodeURIComponent(myUsername)); } catch (e) { return; }
    let chatObjects = data.chats;

    if (chatObjects.length === 0) {
        chatsListMain.innerHTML = `<div class="group-contact-empty" style="padding:30px 15px;">Hali suhbatlaringiz yo'q.<br>Username qidiring yoki guruh yarating.</div>`;
        return;
    }

    chatsListMain.innerHTML = "";
    chatObjects.sort(function(a, b) { let ta = a.last ? a.last.timestamp : (a.createdAt || 0); let tb = b.last ? b.last.timestamp : (b.createdAt || 0); return tb - ta; });
    chatObjects.forEach(function(chat) {
        let badgeHtml = chat.unread > 0 ? `<span class="unread-badge">${chat.unread}</span>` : "";
        let avatarHtml = chat.type === 'group'
            ? `<div class="chat-avatar group-avatar">${escapeHtml(chat.title.substring(0,2).toUpperCase())}</div>`
            : `<div class="chat-avatar" style="background:#5288c1;">${escapeHtml(chat.title.substring(1,3).toUpperCase())}</div>`;
        let timeStr = chat.last ? chat.last.timeStr : "";
        chatsListMain.innerHTML += `<div class="chat-item ${currentChat === chat.id ? 'active' : ''}" onclick="window.switchChat('${escapeHtml(chat.id)}','${chat.type}')">${avatarHtml}<div class="chat-info"><div class="chat-name-row"><span class="chat-title">${escapeHtml(chat.title)}${chat.type === 'group' ? ' 👥' : ''}</span><span class="chat-time">${escapeHtml(timeStr)}</span></div><div class="chat-meta-row"><span class="chat-last-msg">${escapeHtml(messagePreviewText(chat.last))}</span>${badgeHtml}</div></div></div>`;
    });
};

window.switchChat = function(chatId, chatType) {
    currentChat = chatId;
    currentChatType = chatType || (isGroupChat(chatId) ? 'group' : 'private');
    chatSearchQuery = "";
    const searchBar = document.getElementById('in-chat-search-bar');
    const searchInputEl = document.getElementById('in-chat-search-input');
    if (searchBar) searchBar.style.display = 'none';
    if (searchInputEl) searchInputEl.value = "";
    const menu = document.getElementById('chat-options-menu'); if (menu) menu.style.display = 'none';

    const headerTitle = document.getElementById('chat-header-title');
    const groupAddBtn = document.getElementById('btn-group-add');
    const leaveGroupOpt = document.getElementById('opt-leave-group');
    const deleteChatOpt = document.getElementById('opt-delete-chat');

    if (currentChatType === 'group') {
        let g = myGroupsCache.find(x => x.id === chatId);
        if (headerTitle) headerTitle.innerText = g ? (g.name + " 👥") : "Guruh";
        if (groupAddBtn) groupAddBtn.style.display = 'inline-block';
        if (leaveGroupOpt) leaveGroupOpt.style.display = 'block';
        if (deleteChatOpt) deleteChatOpt.innerText = "🗑 Guruh tarixini o'chirish (men uchun)";
    } else {
        if (headerTitle) headerTitle.innerText = chatId;
        if (groupAddBtn) groupAddBtn.style.display = 'none';
        if (leaveGroupOpt) leaveGroupOpt.style.display = 'none';
        if (deleteChatOpt) deleteChatOpt.innerText = "🗑 Suhbatni o'chirish";
    }

    markCurrentChatRead();
    window.renderActiveChats();
    window.loadMessages();
};

function renderMessageContent(m) {
    if (m.type === 'voice') {
        return `<div class="voice-msg-row" onclick="event.stopPropagation(); window.toggleVoicePlay('${m.id}')">
            <div class="voice-play-btn" id="voice-btn-${m.id}">▶</div>
            <div class="voice-wave-bar"></div>
            <span class="voice-duration">${formatDuration(m.duration)}</span>
            <audio id="voice-audio-${m.id}" src="${m.mediaUrl}" style="display:none;"></audio>
        </div>`;
    }
    if (m.type === 'video_round') {
        return `<video class="round-video-msg" id="rv-${m.id}" src="${m.mediaUrl}" muted loop onclick="event.stopPropagation(); window.toggleRoundVideoPlay('${m.id}')"></video>`;
    }
    if (m.type === 'image') {
        return `<img class="msg-image" src="${m.mediaUrl}" onclick="event.stopPropagation(); window.open('${m.mediaUrl}','_blank')">`;
    }
    if (m.type === 'video') {
        return `<video class="msg-video" src="${m.mediaUrl}" controls onclick="event.stopPropagation();"></video>`;
    }
    if (m.type === 'audio_music') {
        return `<div class="msg-music" onclick="event.stopPropagation();"><span class="msg-music-icon">🎵</span><div class="msg-music-info"><span class="msg-music-name">${escapeHtml(m.fileName || 'Musiqa')}</span><audio src="${m.mediaUrl}" controls style="height:32px;width:180px;"></audio></div></div>`;
    }
    return `<span class="msg-text-span">${escapeHtml(m.text)}</span>`;
}

window.toggleVoicePlay = function(msgId) {
    const audioEl = document.getElementById('voice-audio-' + msgId);
    const btnEl = document.getElementById('voice-btn-' + msgId);
    if (!audioEl) return;
    if (audioEl.paused) { audioEl.play(); if (btnEl) btnEl.innerText = "⏸"; audioEl.onended = function() { if (btnEl) btnEl.innerText = "▶"; }; }
    else { audioEl.pause(); if (btnEl) btnEl.innerText = "▶"; }
};

window.toggleRoundVideoPlay = function(msgId) {
    const videoEl = document.getElementById('rv-' + msgId);
    if (!videoEl) return;
    if (videoEl.paused) { videoEl.muted = false; videoEl.play(); } else { videoEl.pause(); }
};

window.loadMessages = async function() {
    const msgBox = document.getElementById('messages-box'); if (!msgBox) return;
    if (!currentChat) { msgBox.innerHTML = `<div id="no-chat-placeholder" class="no-chat-placeholder">Suhbatni tanlang yoki yangi guruh yarating</div>`; return; }

    let data;
    try {
        data = await apiCall('GET', '/api/messages?me=' + encodeURIComponent(myUsername) + '&chatType=' + currentChatType + '&target=' + encodeURIComponent(currentChat));
    } catch (e) { return; }

    let messages = data.messages.slice().sort((a, b) => a.timestamp - b.timestamp);
    let htmlContent = ""; let matchCount = 0;

    messages.forEach(function(m) {
        let isShow = true;
        if (chatSearchQuery) {
            let hay = (m.text || m.fileName || "").toLowerCase();
            if (!hay.includes(chatSearchQuery)) isShow = false;
        }
        if (isShow) {
            matchCount++;
            let sideClass = m.sender === myUsername ? 'me' : 'other';
            let readTick = m.isRead ? '✓✓' : '✓';
            let senderLabel = sideClass === 'other' ? `<span class="msg-sender">${escapeHtml(m.sender)}</span>` : '';
            let bubbleOnClick = m.type === 'text' ? `onclick="window.openDeleteModal('${m.id}')"` : `oncontextmenu="event.preventDefault(); window.openDeleteModal('${m.id}'); return false;" ondblclick="window.openDeleteModal('${m.id}')"`;
            htmlContent += `<div class="msg-row ${sideClass}"><div class="msg-bubble" ${bubbleOnClick}>${sideClass === 'other' ? senderLabel : ''}${renderMessageContent(m)}<div class="msg-meta"><span>${escapeHtml(m.timeStr)}</span>${sideClass === 'me' ? `<span class="tick-icon ${m.isRead ? 'read' : ''}">${readTick}</span>` : ''}</div></div></div>`;
        }
    });

    if (chatSearchQuery && matchCount === 0) htmlContent = `<div class="no-chat-placeholder">Hech narsa topilmadi</div>`;

    let shouldScroll = (msgBox.scrollHeight - msgBox.scrollTop - msgBox.clientHeight < 100);
    msgBox.innerHTML = htmlContent;
    if (shouldScroll || msgBox.scrollTop === 0) msgBox.scrollTop = msgBox.scrollHeight;
};

window.openDeleteModal = function(msgId) {
    activeDeleteMsgId = msgId;
    const modal = document.getElementById('tg-delete-modal');
    const deleteBothRow = document.getElementById('delete-both-container');
    const deleteBothCheckbox = document.getElementById('delete-both-checkbox');
    if (!modal) return;
    if (deleteBothCheckbox) deleteBothCheckbox.checked = false;
    if (deleteBothRow) deleteBothRow.style.display = (currentChatType === 'private') ? 'flex' : 'none';
    modal.style.display = 'flex';
};

function setupModalEvents() {
    const modal = document.getElementById('tg-delete-modal');
    const cancelBtn = document.getElementById('modal-cancel-btn');
    const confirmBtn = document.getElementById('modal-confirm-btn');
    const deleteBothCheckbox = document.getElementById('delete-both-checkbox');
    if (!modal || !cancelBtn || !confirmBtn) return;

    cancelBtn.addEventListener('click', function() { modal.style.display = 'none'; activeDeleteMsgId = null; });
    confirmBtn.addEventListener('click', async function() {
        if (!activeDeleteMsgId) return;
        let deleteBoth = deleteBothCheckbox ? deleteBothCheckbox.checked : false;
        try { await apiCall('POST', '/api/messages/delete', { msgId: activeDeleteMsgId, username: myUsername, deleteBoth: deleteBoth }); } catch (e) {}
        modal.style.display = 'none'; activeDeleteMsgId = null;
        window.loadMessages(); window.renderActiveChats();
    });
}

// =========================================================================
// 5-BO'LAK: XABAR YUBORISH (MATN)
// =========================================================================

function buildBaseMessage(type) {
    return {
        sender: myUsername,
        chatType: currentChatType,
        target: currentChat,
        type: type || 'text'
    };
}

function sendSocketMessage(msg) {
    socket.emit('message:send', msg);
}

function setupMessageSending() {
    const sendBtn = document.getElementById('send-btn');
    const msgInput = document.getElementById('message-input');
    if (!sendBtn || !msgInput) return;

    function sendMsgAction() {
        if (!currentChat) { alert("Avval suhbat tanlang!"); return; }
        let textVal = msgInput.value.trim(); if (textVal === "") return;
        let newMsg = buildBaseMessage('text');
        newMsg.text = textVal;
        sendSocketMessage(newMsg);
        msgInput.value = "";
    }
    sendBtn.addEventListener('click', sendMsgAction);
    msgInput.addEventListener('keypress', function(e) { if (e.key === 'Enter') sendMsgAction(); });
}

// =========================================================================
// 6-BO'LAK: GURUHLAR
// =========================================================================

let groupModalMode = 'create';
let groupModalTargetId = null;

function setupGroupFeatures() {
    const newGroupBtn = document.getElementById('new-group-btn');
    const groupAddBtn = document.getElementById('btn-group-add');
    const modal = document.getElementById('group-modal');
    const cancelBtn = document.getElementById('group-modal-cancel');
    const confirmBtn = document.getElementById('group-modal-confirm');
    if (!modal) return;

    if (newGroupBtn) newGroupBtn.addEventListener('click', function() { openGroupModal('create', null); });
    if (groupAddBtn) groupAddBtn.addEventListener('click', function() { if (currentChatType === 'group') openGroupModal('add', currentChat); });
    if (cancelBtn) cancelBtn.addEventListener('click', function() { modal.style.display = 'none'; });
    if (confirmBtn) confirmBtn.addEventListener('click', confirmGroupModal);
}

async function openGroupModal(mode, groupId) {
    groupModalMode = mode; groupModalTargetId = groupId;
    const modal = document.getElementById('group-modal');
    const title = document.getElementById('group-modal-title');
    const nameRow = document.getElementById('group-name-row');
    const nameInput = document.getElementById('group-name-input');
    if (!modal) return;

    if (mode === 'create') { title.innerText = "Yangi guruh"; nameRow.style.display = 'block'; nameInput.value = ""; }
    else { title.innerText = "Guruhga odam qo'shish"; nameRow.style.display = 'none'; }

    let contacts = [];
    try { let data = await apiCall('GET', '/api/contacts/' + encodeURIComponent(myUsername)); contacts = data.contacts; } catch (e) {}

    let excludeList = [];
    if (mode === 'add' && groupId) { let g = myGroupsCache.find(x => x.id === groupId); if (g) excludeList = g.members; }
    let candidates = contacts.filter(c => !excludeList.includes(c));

    const listBox = document.getElementById('group-contacts-list');
    if (candidates.length === 0) {
        listBox.innerHTML = `<div class="group-contact-empty">Taklif qilish uchun kontakt yo'q. Avval username qidirib, suhbat boshlang.</div>`;
    } else {
        listBox.innerHTML = "";
        candidates.forEach(function(c) {
            let row = document.createElement('label');
            row.className = 'group-contact-row';
            row.innerHTML = `<input type="checkbox" value="${escapeHtml(c)}"><span>${escapeHtml(c)}</span>`;
            listBox.appendChild(row);
        });
    }
    modal.style.display = 'flex';
}

async function confirmGroupModal() {
    const modal = document.getElementById('group-modal');
    const nameInput = document.getElementById('group-name-input');
    const listBox = document.getElementById('group-contacts-list');
    let checked = Array.from(listBox.querySelectorAll('input[type=checkbox]:checked')).map(cb => cb.value);

    if (groupModalMode === 'create') {
        let gname = nameInput.value.trim();
        if (gname === "") { alert("Guruh nomini kiriting!"); return; }
        try {
            let data = await apiCall('POST', '/api/groups/create', { name: gname, creator: myUsername, members: checked });
            modal.style.display = 'none';
            await refreshGroupsCache();
            window.switchChat(data.group.id, 'group');
        } catch (e) { alert(e.message); }
    } else {
        if (checked.length > 0) {
            try { await apiCall('POST', '/api/groups/' + groupModalTargetId + '/add-members', { members: checked }); } catch (e) {}
        }
        modal.style.display = 'none';
        await refreshGroupsCache();
        window.renderActiveChats();
    }
}

async function leaveGroup(groupId) {
    try { await apiCall('POST', '/api/groups/' + groupId + '/leave', { username: myUsername }); } catch (e) {}
    currentChat = null;
    await refreshGroupsCache();
    window.renderActiveChats();
    window.loadMessages();
    document.getElementById('chat-header-title').innerText = "Suhbat tanlang";
}

// =========================================================================
// 7-BO'LAK: SUHBAT SOZLAMALARI (QIDIRUV, O'CHIRISH)
// =========================================================================

function setupChatOptionsMenu() {
    const optBtn = document.getElementById('btn-chat-options');
    const menu = document.getElementById('chat-options-menu');
    const deleteOpt = document.getElementById('opt-delete-chat');
    const leaveOpt = document.getElementById('opt-leave-group');
    if (!optBtn || !menu) return;

    optBtn.addEventListener('click', function(e) { e.stopPropagation(); if (!currentChat) return; menu.style.display = menu.style.display === 'none' ? 'block' : 'none'; });
    document.addEventListener('click', function(e) { if (menu.style.display !== 'none' && !menu.contains(e.target) && e.target !== optBtn) menu.style.display = 'none'; });

    if (deleteOpt) deleteOpt.addEventListener('click', function() {
        menu.style.display = 'none'; if (!currentChat) return;
        const chatDeleteModal = document.getElementById('chat-delete-modal');
        const bothRow = document.getElementById('chat-delete-both-row');
        if (bothRow) bothRow.style.display = (currentChatType === 'private') ? 'flex' : 'none';
        if (chatDeleteModal) chatDeleteModal.style.display = 'flex';
    });

    if (leaveOpt) leaveOpt.addEventListener('click', function() {
        menu.style.display = 'none'; if (currentChatType !== 'group') return;
        if (confirm("Haqiqatan ham bu guruhdan chiqmoqchimisiz?")) leaveGroup(currentChat);
    });

    const chatDeleteCancel = document.getElementById('chat-delete-cancel');
    const chatDeleteConfirm = document.getElementById('chat-delete-confirm');
    const chatDeleteModal = document.getElementById('chat-delete-modal');
    const bothCheckbox = document.getElementById('chat-delete-both-checkbox');

    if (chatDeleteCancel) chatDeleteCancel.addEventListener('click', function() { chatDeleteModal.style.display = 'none'; });
    if (chatDeleteConfirm) chatDeleteConfirm.addEventListener('click', async function() {
        if (!currentChat) { chatDeleteModal.style.display = 'none'; return; }
        let deleteBoth = bothCheckbox ? bothCheckbox.checked : false;
        try { await apiCall('POST', '/api/chats/delete', { username: myUsername, chatType: currentChatType, target: currentChat, deleteBoth: deleteBoth }); } catch (e) {}
        chatDeleteModal.style.display = 'none';
        currentChat = null;
        document.getElementById('chat-header-title').innerText = "Suhbat tanlang";
        window.renderActiveChats(); window.loadMessages();
    });
}

function setupInChatSearch() {
    const searchBtn = document.getElementById('btn-search-chat');
    const searchBar = document.getElementById('in-chat-search-bar');
    const searchInput = document.getElementById('in-chat-search-input');
    const closeBtn = document.getElementById('in-chat-search-close');
    if (!searchBtn || !searchBar || !searchInput || !closeBtn) return;

    searchBtn.addEventListener('click', function() {
        if (!currentChat) return;
        searchBar.style.display = searchBar.style.display === 'none' ? 'flex' : 'none';
        if (searchBar.style.display === 'flex') searchInput.focus();
    });
    closeBtn.addEventListener('click', function() { searchBar.style.display = 'none'; searchInput.value = ""; chatSearchQuery = ""; window.loadMessages(); });
    searchInput.addEventListener('input', function() { chatSearchQuery = searchInput.value.trim().toLowerCase(); window.loadMessages(); });
}

// =========================================================================
// 8-BO'LAK: RASM / VIDEO / MUSIQA YUBORISH (SERVERGA YUKLAB)
// =========================================================================

async function uploadFile(fileOrBlob, filename) {
    let form = new FormData();
    form.append('file', fileOrBlob, filename || 'file');
    let res = await fetch('/api/upload', { method: 'POST', body: form });
    let data = await res.json();
    if (!res.ok) throw new Error(data.error || "Yuklashda xatolik");
    return data; // {url, fileName}
}

function setupAttachMenu() {
    const attachIcon = document.getElementById('attach-icon');
    const attachMenu = document.getElementById('attach-menu');
    const mediaBtn = document.getElementById('attach-media-btn');
    const musicBtn = document.getElementById('attach-music-btn');
    const mediaInput = document.getElementById('file-media-input');
    const musicInput = document.getElementById('file-music-input');
    if (!attachIcon || !attachMenu) return;

    attachIcon.addEventListener('click', function(e) {
        e.stopPropagation();
        if (!currentChat) { alert("Avval suhbat tanlang!"); return; }
        attachMenu.style.display = attachMenu.style.display === 'none' ? 'block' : 'none';
    });
    document.addEventListener('click', function(e) { if (attachMenu.style.display !== 'none' && !attachMenu.contains(e.target) && e.target !== attachIcon) attachMenu.style.display = 'none'; });

    if (mediaBtn) mediaBtn.addEventListener('click', function() { attachMenu.style.display = 'none'; mediaInput.click(); });
    if (musicBtn) musicBtn.addEventListener('click', function() { attachMenu.style.display = 'none'; musicInput.click(); });

    if (mediaInput) mediaInput.addEventListener('change', async function() {
        let file = mediaInput.files[0]; if (!file) return;
        let isVideo = file.type.startsWith('video/');
        try {
            let up = await uploadFile(file, file.name);
            let msg = buildBaseMessage(isVideo ? 'video' : 'image');
            msg.mediaUrl = up.url; msg.fileName = up.fileName;
            sendSocketMessage(msg);
        } catch (e) { alert(e.message); }
        mediaInput.value = "";
    });

    if (musicInput) musicInput.addEventListener('change', async function() {
        let file = musicInput.files[0]; if (!file) return;
        try {
            let up = await uploadFile(file, file.name);
            let msg = buildBaseMessage('audio_music');
            msg.mediaUrl = up.url; msg.fileName = up.fileName;
            sendSocketMessage(msg);
        } catch (e) { alert(e.message); }
        musicInput.value = "";
    });
}

// =========================================================================
// 9-BO'LAK: OVOZLI XABAR
// =========================================================================

function setupVoiceMessages() {
    const micBtn = document.getElementById('mic-btn');
    const recordBar = document.getElementById('voice-record-bar');
    const timerEl = document.getElementById('voice-record-timer');
    if (!micBtn) return;

    let startRecording = function(e) {
        if (e) e.preventDefault();
        if (!currentChat) { alert("Avval suhbat tanlang!"); return; }
        if (voiceRecorder) return;
        navigator.mediaDevices.getUserMedia({ audio: true }).then(function(stream) {
            voiceRecordStream = stream; voiceChunks = [];
            voiceRecorder = new MediaRecorder(stream);
            voiceRecorder.ondataavailable = function(ev) { if (ev.data && ev.data.size > 0) voiceChunks.push(ev.data); };
            voiceRecorder.onstop = function() { finishVoiceRecording(); };
            voiceRecorder.start();
            voiceStartTime = Date.now();
            if (recordBar) recordBar.style.display = 'flex';
            voiceTimerInterval = setInterval(function() { let sec = Math.floor((Date.now() - voiceStartTime) / 1000); if (timerEl) timerEl.innerText = formatDuration(sec); }, 250);
        }).catch(function() { alert("Mikrofonga ruxsat berilmadi."); });
    };

    let stopRecording = function(e) {
        if (e) e.preventDefault();
        if (!voiceRecorder) return;
        if (voiceRecorder.state !== 'inactive') voiceRecorder.stop();
        if (voiceRecordStream) voiceRecordStream.getTracks().forEach(t => t.stop());
        if (voiceTimerInterval) { clearInterval(voiceTimerInterval); voiceTimerInterval = null; }
        if (recordBar) recordBar.style.display = 'none';
    };

    async function finishVoiceRecording() {
        let duration = (Date.now() - voiceStartTime) / 1000;
        if (duration < 0.6 || voiceChunks.length === 0) { voiceRecorder = null; voiceChunks = []; return; }
        let blob = new Blob(voiceChunks, { type: 'audio/webm' });
        try {
            let up = await uploadFile(blob, 'voice.webm');
            let msg = buildBaseMessage('voice');
            msg.mediaUrl = up.url; msg.duration = duration;
            sendSocketMessage(msg);
        } catch (e) { alert(e.message); }
        voiceRecorder = null; voiceChunks = [];
    }

    micBtn.addEventListener('mousedown', startRecording);
    micBtn.addEventListener('touchstart', startRecording, { passive: false });
    micBtn.addEventListener('mouseup', stopRecording);
    micBtn.addEventListener('mouseleave', function() { if (voiceRecorder && voiceRecorder.state === 'recording') stopRecording(); });
    micBtn.addEventListener('touchend', stopRecording);
}

// =========================================================================
// 10-BO'LAK: DUMALOQ VIDEO XABAR
// =========================================================================

function setupRoundVideoMessages() {
    const openBtn = document.getElementById('round-video-btn');
    const modal = document.getElementById('round-video-modal');
    const previewEl = document.getElementById('round-video-preview');
    const timerEl = document.getElementById('round-video-timer');
    const recordBtn = document.getElementById('round-video-record');
    const sendBtn = document.getElementById('round-video-send');
    const cancelBtn = document.getElementById('round-video-cancel');
    if (!openBtn || !modal) return;

    let localRoundStream = null;

    openBtn.addEventListener('click', function() {
        if (!currentChat) { alert("Avval suhbat tanlang!"); return; }
        roundVideoFinalBlob = null;
        sendBtn.style.display = 'none'; recordBtn.style.display = 'flex'; recordBtn.innerText = "⏺"; recordBtn.classList.remove('recording');
        timerEl.innerText = "00:00";
        modal.style.display = 'flex';
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 400, height: 400 }, audio: true }).then(function(stream) {
            localRoundStream = stream; previewEl.srcObject = stream; previewEl.muted = true; previewEl.play();
        }).catch(function() { alert("Kamera yoki mikrofonga ruxsat berilmadi."); closeRoundVideoModal(); });
    });

    recordBtn.addEventListener('click', function() {
        if (!localRoundStream) return;
        if (!roundVideoRecorder || roundVideoRecorder.state === 'inactive') {
            roundVideoChunks = [];
            roundVideoRecorder = new MediaRecorder(localRoundStream, { mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus') ? 'video/webm;codecs=vp8,opus' : 'video/webm' });
            roundVideoRecorder.ondataavailable = function(ev) { if (ev.data && ev.data.size > 0) roundVideoChunks.push(ev.data); };
            roundVideoRecorder.onstop = function() { onRoundVideoStopped(); };
            roundVideoRecorder.start();
            roundVideoSeconds = 0;
            recordBtn.innerText = "⏹"; recordBtn.classList.add('recording');
            roundVideoTimerInterval = setInterval(function() { roundVideoSeconds++; timerEl.innerText = formatDuration(roundVideoSeconds); if (roundVideoSeconds >= 30) roundVideoRecorder.stop(); }, 1000);
        } else { roundVideoRecorder.stop(); }
    });

    function onRoundVideoStopped() {
        if (roundVideoTimerInterval) { clearInterval(roundVideoTimerInterval); roundVideoTimerInterval = null; }
        recordBtn.style.display = 'none';
        if (roundVideoChunks.length === 0) { closeRoundVideoModal(); return; }
        roundVideoFinalBlob = new Blob(roundVideoChunks, { type: 'video/webm' });
        sendBtn.style.display = 'inline-block';
    }

    sendBtn.addEventListener('click', async function() {
        if (!roundVideoFinalBlob) return;
        try {
            let up = await uploadFile(roundVideoFinalBlob, 'round.webm');
            let msg = buildBaseMessage('video_round');
            msg.mediaUrl = up.url; msg.duration = roundVideoSeconds;
            sendSocketMessage(msg);
        } catch (e) { alert(e.message); }
        closeRoundVideoModal();
    });

    cancelBtn.addEventListener('click', function() { closeRoundVideoModal(); });

    function closeRoundVideoModal() {
        if (roundVideoRecorder && roundVideoRecorder.state !== 'inactive') roundVideoRecorder.stop();
        if (localRoundStream) { localRoundStream.getTracks().forEach(t => t.stop()); localRoundStream = null; }
        if (roundVideoTimerInterval) { clearInterval(roundVideoTimerInterval); roundVideoTimerInterval = null; }
        roundVideoFinalBlob = null;
        modal.style.display = 'none';
    }
}

// =========================================================================
// 11-BO'LAK: EMOJI PANELI
// =========================================================================

function initTelegramEmojiPicker() {
    const toggleBtn = document.getElementById('emoji-toggle-btn'); const pickerBox = document.getElementById('tg-emoji-picker');
    const tabsHeader = document.getElementById('emoji-cats-tabs'); const gridContent = document.getElementById('emoji-grid-content'); const msgInput = document.getElementById('message-input');
    if (!toggleBtn || !pickerBox || !tabsHeader || !gridContent || !msgInput) return;
    if (tabsHeader.dataset.inited) return;
    tabsHeader.dataset.inited = "1";

    toggleBtn.onclick = function(e) { e.stopPropagation(); pickerBox.style.display = pickerBox.style.display === 'none' ? 'flex' : 'none'; };
    document.addEventListener('click', function(e) { if (!pickerBox.contains(e.target) && e.target !== toggleBtn) pickerBox.style.display = 'none'; });
    tabsHeader.innerHTML = "";
    EMOJI_CATEGORIES.forEach(function(cat, idx) {
        let span = document.createElement('span'); span.className = 'emoji-tab-btn' + (idx === 0 ? ' active' : ''); span.innerText = cat.title;
        span.onclick = function(e) { e.stopPropagation(); document.querySelectorAll('.emoji-tab-btn').forEach(b => b.classList.remove('active')); span.classList.add('active'); renderEmojiGrid(cat.list); };
        tabsHeader.appendChild(span);
    });
    function renderEmojiGrid(emojis) {
        gridContent.innerHTML = "";
        emojis.forEach(function(emoji) {
            let item = document.createElement('span'); item.className = 'emoji-picker-item'; item.innerText = emoji;
            item.onclick = function(e) { e.stopPropagation(); msgInput.value += emoji; msgInput.focus(); };
            gridContent.appendChild(item);
        });
    }
    renderEmojiGrid(EMOJI_CATEGORIES[0].list);
}
// darhol ishga tushirish (login oynasi yashiringandan keyin ham ishlashi uchun)
document.addEventListener("DOMContentLoaded", initTelegramEmojiPicker);

// =========================================================================
// 12-BO'LAK: HAQIQIY QO'NG'IROQ (WebRTC) - ASOSIY BOSHQARUV
// =========================================================================

function setupCallButtons() {
    const voiceBtn = document.getElementById('btn-voice-call'); const videoBtn = document.getElementById('btn-video-call');
    if (voiceBtn) voiceBtn.addEventListener('click', function() { makeCall('audio'); });
    if (videoBtn) videoBtn.addEventListener('click', function() { makeCall('video'); });

    const muteBtn = document.getElementById('call-mute-btn'); const speakerBtn = document.getElementById('call-speaker-btn');
    if (muteBtn) muteBtn.addEventListener('click', toggleMute);
    if (speakerBtn) speakerBtn.addEventListener('click', toggleSpeaker);
    const muteVideoBtn = document.getElementById('call-mute-video-btn'); if (muteVideoBtn) muteVideoBtn.addEventListener('click', toggleMute);
    const videoSpeakerBtn = document.getElementById('call-video-speaker-btn'); if (videoSpeakerBtn) videoSpeakerBtn.addEventListener('click', toggleSpeaker);

    const camDummyBtn = document.getElementById('call-video-dummy-btn');
    if (camDummyBtn) camDummyBtn.addEventListener('click', function() { switchCallToVideo(); });
    const flipBtn = document.getElementById('call-flip-camera-btn'); if (flipBtn) flipBtn.addEventListener('click', flipCamera);
    const toggleCamBtn = document.getElementById('call-toggle-camera-btn'); if (toggleCamBtn) toggleCamBtn.addEventListener('click', toggleCameraOnOff);

    const endVideoBtn = document.getElementById('call-end-video-btn'); if (endVideoBtn) endVideoBtn.addEventListener('click', hangUpCall);
    const endBtn = document.getElementById('call-end-btn'); if (endBtn) endBtn.addEventListener('click', hangUpCall);

    const minimizeBtn = document.getElementById('call-minimize-btn'); if (minimizeBtn) minimizeBtn.addEventListener('click', minimizeCall);
    const addPersonBtn = document.getElementById('call-add-person-btn');
    if (addPersonBtn) addPersonBtn.addEventListener('click', function(e) { e.stopPropagation(); alert("Qo'ng'iroq davomida odam qo'shish hozircha demo tarzida ishlaydi (guruh qo'ng'iroqlarida mavjud)."); });

    const videoContainer = document.getElementById('call-video-container');
    if (videoContainer) videoContainer.addEventListener('click', function(e) { toggleCallUIVisibility(e); });
}

function switchBottomBar(type) {
    const audioBar = document.getElementById('call-bottom-audio-bar'); const videoBar = document.getElementById('call-bottom-video-bar');
    if (!audioBar || !videoBar) return;
    if (type === 'video') { audioBar.style.display = 'none'; videoBar.style.display = 'flex'; } else { audioBar.style.display = 'flex'; videoBar.style.display = 'none'; }
}

// ---- QO'NG'IROQ BOSHLASH (CHIQUVCHI) ----
function makeCall(type) {
    if (!currentChat) { alert("Avval suhbat tanlang!"); return; }
    if (isCallActive) { alert("Siz allaqachon qo'ng'iroqdasiz!"); return; }
    currentCallType = type || 'audio';
    cameraFacingMode = 'user'; isCameraOff = false;

    if (currentChatType === 'group') {
        let g = myGroupsCache.find(x => x.id === currentChat);
        if (!g) return;
        let others = g.members.filter(m => m !== myUsername);
        if (others.length === 0) { alert("Guruhda boshqa a'zo yo'q!"); return; }
        socket.emit('call:invite', { from: myUsername, isGroup: true, groupId: currentChat, groupName: g.name, members: others, type: currentCallType, timestamp: Date.now() });
        currentCallDirection = 'outgoing';
        isCallActive = true;
        showCallUI(g.name, 'outgoing', currentCallType, true);
        activateLocalMedia(currentCallType === 'video').then(function() {
            // Guruh qo'ng'irog'i: haqiqiy ko'p-tomonlama ulanish o'rniga demo namoyish (mesh-signaling talab qiladi)
            showCallEmojiCode(); startSecondsTimer();
            document.getElementById('call-status').innerText = "Ulanmoqda ••";
        });
        return;
    }

    currentCallPeer = currentChat;
    currentCallDirection = 'outgoing';
    isCallActive = true;
    showCallUI(currentChat, 'outgoing', currentCallType, false);
    document.getElementById('call-status').innerText = "So‘rov yuborilmoqda ••";
    playRingtone();
    socket.emit('call:invite', { from: myUsername, to: currentChat, type: currentCallType, timestamp: Date.now() });
}

// ---- KIRUVCHI QO'NG'IROQ ----
function handleIncomingCall(data) {
    if (isCallActive) { socket.emit('call:reject', { from: myUsername, to: data.from }); return; }
    isCallActive = true;
    currentCallType = data.type || 'audio';
    currentCallDirection = 'incoming';
    if (data.isGroup) {
        currentCallPeer = null;
        showCallUI(data.groupName, 'incoming', currentCallType, true);
        window._pendingGroupCallInviter = data.from;
    } else {
        currentCallPeer = data.from;
        showCallUI(data.from, 'incoming', currentCallType, false);
    }
    playRingtone();
    document.getElementById('call-accept-btn').onclick = function() { acceptCall(data); };
}

function acceptCall(incomingData) {
    document.getElementById('incoming-accept-box').style.display = 'none';
    stopRingtone();
    document.getElementById('call-status').innerText = "Ulanmoqda ••";

    if (incomingData && incomingData.isGroup) {
        activateLocalMedia(currentCallType === 'video').then(function() { showCallEmojiCode(); startSecondsTimer(); });
        return;
    }

    activateLocalMedia(currentCallType === 'video').then(function() {
        socket.emit('call:accept', { from: myUsername, to: currentCallPeer });
    });
}

// Chaqiruvchi tomonda: suhbatdosh qabul qildi -> Offer yaratamiz
async function handleCallAccepted(data) {
    if (currentCallDirection !== 'outgoing' || currentCallPeer !== data.from) return;
    stopRingtone();
    document.getElementById('call-status').innerText = "Ulanmoqda ••";
    await activateLocalMedia(currentCallType === 'video');
    createPeerConnection();
    localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));
    let offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);
    socket.emit('call:offer', { from: myUsername, to: currentCallPeer, sdp: offer });
}

// Qabul qiluvchi tomonda: Offer keldi -> Answer yaratamiz
async function handleCallOffer(data) {
    if (!currentCallPeer) currentCallPeer = data.from;
    if (currentCallPeer !== data.from) return;
    createPeerConnection();
    if (localStream) { localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream)); }
    await peerConnection.setRemoteDescription(new RTCSessionDescription(data.sdp));
    let answer = await peerConnection.createAnswer();
    await peerConnection.setLocalDescription(answer);
    socket.emit('call:answer', { from: myUsername, to: currentCallPeer, sdp: answer });
    showCallEmojiCode(); startSecondsTimer();
}

async function handleCallAnswer(data) {
    if (!peerConnection || currentCallPeer !== data.from) return;
    await peerConnection.setRemoteDescription(new RTCSessionDescription(data.sdp));
    showCallEmojiCode(); startSecondsTimer();
}

async function handleRemoteIce(data) {
    if (!peerConnection || currentCallPeer !== data.from) return;
    try { await peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate)); } catch (e) {}
}

function createPeerConnection() {
    if (peerConnection) return;
    peerConnection = new RTCPeerConnection(RTC_CONFIG);
    remoteMediaStream = new MediaStream();

    peerConnection.onicecandidate = function(e) {
        if (e.candidate && currentCallPeer) socket.emit('call:ice', { from: myUsername, to: currentCallPeer, candidate: e.candidate });
    };
    peerConnection.ontrack = function(e) {
        e.streams[0].getTracks().forEach(t => remoteMediaStream.addTrack(t));
        const remoteVideoEl = document.getElementById('remote-video');
        if (remoteVideoEl) remoteVideoEl.srcObject = remoteMediaStream;
        setupRemoteAudioGain(remoteMediaStream);
    };
    peerConnection.onconnectionstatechange = function() {
        if (peerConnection && (peerConnection.connectionState === 'failed' || peerConnection.connectionState === 'disconnected')) {
            // ulanish uzilsa qo'ng'iroqni yakunlaymiz
        }
    };
}

function setupRemoteAudioGain(stream) {
    try {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        let source = audioCtx.createMediaStreamSource(stream);
        remoteGainNode = audioCtx.createGain();
        remoteGainNode.gain.value = isSpeakerOn ? 2.2 : 1.0;
        source.connect(remoteGainNode);
        remoteGainNode.connect(audioCtx.destination);
    } catch (e) { /* jim */ }
}

async function activateLocalMedia(withVideo) {
    try {
        localStream = await navigator.mediaDevices.getUserMedia({ video: withVideo ? { facingMode: cameraFacingMode } : false, audio: true });
        const localVideoEl = document.getElementById('local-video');
        const videoContainer = document.getElementById('call-video-container');
        if (withVideo) {
            if (videoContainer) videoContainer.style.display = 'block';
            if (localVideoEl) localVideoEl.srcObject = localStream;
        }
        if (peerConnection) { localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream)); }
    } catch (error) { console.error("Media ulashda xatolik:", error); alert("Kamera/mikrofonga ruxsat berilmadi."); }
}

function switchCallToVideo() {
    currentCallType = 'video';
    switchBottomBar('video');
    if (!localStream || localStream.getVideoTracks().length === 0) {
        navigator.mediaDevices.getUserMedia({ video: { facingMode: cameraFacingMode }, audio: false }).then(function(camStream) {
            let videoTrack = camStream.getVideoTracks()[0];
            if (localStream) localStream.addTrack(videoTrack); else localStream = camStream;
            const videoContainer = document.getElementById('call-video-container');
            const localVideoEl = document.getElementById('local-video');
            if (videoContainer) videoContainer.style.display = 'block';
            if (localVideoEl) localVideoEl.srcObject = localStream;
            if (peerConnection) peerConnection.addTrack(videoTrack, localStream);
        }).catch(function() { alert("Kameraga ruxsat berilmadi."); });
    }
}

async function flipCamera() {
    if (!localStream) return;
    cameraFacingMode = cameraFacingMode === 'user' ? 'environment' : 'user';
    let oldTrack = localStream.getVideoTracks()[0];
    try {
        let newStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: cameraFacingMode }, audio: false });
        let newVideoTrack = newStream.getVideoTracks()[0];
        if (oldTrack) { localStream.removeTrack(oldTrack); oldTrack.stop(); }
        localStream.addTrack(newVideoTrack);
        const localVideoEl = document.getElementById('local-video');
        if (localVideoEl) localVideoEl.srcObject = localStream;
        if (peerConnection) {
            let sender = peerConnection.getSenders().find(s => s.track && s.track.kind === 'video');
            if (sender) sender.replaceTrack(newVideoTrack); else peerConnection.addTrack(newVideoTrack, localStream);
        }
    } catch (error) { console.error("Kamerani almashtirishda xatolik:", error); }
}

function toggleCameraOnOff() {
    if (!localStream) return;
    isCameraOff = !isCameraOff;
    localStream.getVideoTracks().forEach(track => { track.enabled = !isCameraOff; });
    const btn = document.getElementById('call-toggle-camera-btn'); const label = document.getElementById('call-toggle-camera-label');
    if (isCameraOff) { if (btn) { btn.classList.add('active-mode'); btn.innerText = "🚫"; } if (label) label.innerText = "Yoqish"; }
    else { if (btn) { btn.classList.remove('active-mode'); btn.innerText = "📷"; } if (label) label.innerText = "O‘chirish"; }
}

function toggleCallUIVisibility(e) {
    if (e.target.closest('.call-icon-btn') || e.target.closest('.tg-round-btn') || e.target.closest('.add-person-panel')) return;
    const overlay = document.getElementById('tg-call-overlay');
    if (overlay) overlay.classList.toggle('ui-hidden');
}

function minimizeCall() {
    const callOverlay = document.getElementById('tg-call-overlay'); if (!callOverlay) return;
    isCallMinimized = true; callOverlay.style.display = 'none';
    let bubble = document.getElementById('call-minimized-bubble');
    if (!bubble) { bubble = document.createElement('div'); bubble.id = 'call-minimized-bubble'; bubble.className = 'call-minimized-bubble'; document.body.appendChild(bubble); bubble.onclick = restoreCall; }
    updateMinimizedBubble(); bubble.style.display = 'flex';
}
function updateMinimizedBubble() {
    const bubble = document.getElementById('call-minimized-bubble'); if (!bubble) return;
    const statusEl = document.getElementById('call-status'); let label = statusEl ? statusEl.innerText : "Qo'ng'iroq";
    bubble.innerHTML = `<span class="bubble-icon">📞</span><span>${label.replace('📶 ', '')}</span>`;
}
function restoreCall() {
    const callOverlay = document.getElementById('tg-call-overlay'); const bubble = document.getElementById('call-minimized-bubble');
    isCallMinimized = false; if (bubble) bubble.style.display = 'none'; if (callOverlay) callOverlay.style.display = 'flex';
}

function generateCallEmojiCode(seed) {
    let s = 0; String(seed).split('').forEach(ch => { s = (s * 31 + ch.charCodeAt(0)) % 100000; });
    function nextRand() { s = (s * 9301 + 49297) % 233280; return s / 233280; }
    let picked = []; let pool = CALL_CODE_EMOJIS.slice();
    for (let i = 0; i < 4; i++) { let idx = Math.floor(nextRand() * pool.length); picked.push(pool[idx]); pool.splice(idx, 1); }
    return picked.join(' ');
}
function showCallEmojiCode() {
    const codeBox = document.getElementById('call-emoji-code'); const addPersonBtn = document.getElementById('call-add-person-btn'); const videoSpeakerBtn = document.getElementById('call-video-speaker-btn');
    if (!codeBox) return;
    if (!currentCallEmojiCode) currentCallEmojiCode = generateCallEmojiCode((currentCallPeer || 'group') + '_' + myUsername + '_' + Date.now());
    codeBox.innerText = currentCallEmojiCode; codeBox.style.display = 'flex';
    if (currentCallType === 'video') { if (videoSpeakerBtn) videoSpeakerBtn.style.display = 'flex'; if (addPersonBtn) addPersonBtn.style.display = 'none'; }
    else { if (addPersonBtn) addPersonBtn.style.display = 'flex'; if (videoSpeakerBtn) videoSpeakerBtn.style.display = 'none'; }
}
function hideCallEmojiCode() {
    const codeBox = document.getElementById('call-emoji-code'); const addPersonBtn = document.getElementById('call-add-person-btn'); const videoSpeakerBtn = document.getElementById('call-video-speaker-btn'); const addPanel = document.getElementById('add-person-panel');
    if (codeBox) codeBox.style.display = 'none'; if (addPersonBtn) addPersonBtn.style.display = 'none'; if (videoSpeakerBtn) videoSpeakerBtn.style.display = 'none'; if (addPanel) addPanel.style.display = 'none';
    currentCallEmojiCode = "";
}

function showCallUI(targetName, direction, type, isGroup) {
    const callOverlay = document.getElementById('tg-call-overlay'); const callAvatar = document.getElementById('call-avatar');
    const callTargetName = document.getElementById('call-target-name'); const callStatus = document.getElementById('call-status'); const acceptBox = document.getElementById('incoming-accept-box');
    if (!callOverlay) return;
    currentCallType = type || 'audio'; cameraFacingMode = 'user'; isCameraOff = false;
    switchBottomBar(currentCallType);
    callOverlay.classList.remove('ui-hidden');
    const videoContainer = document.getElementById('call-video-container'); if (videoContainer) videoContainer.style.display = 'none';

    callTargetName.innerText = targetName;
    callAvatar.innerText = isGroup ? targetName.substring(0,2).toUpperCase() : targetName.substring(1,3).toUpperCase();
    callAvatar.style.background = isGroup ? 'rgba(125,95,201,0.4)' : 'rgba(255, 255, 255, 0.2)';
    isMuted = false; isSpeakerOn = false;
    document.getElementById('call-mute-btn').classList.remove('active-mode');
    document.getElementById('call-speaker-btn').classList.remove('active-mode');
    document.getElementById('call-mute-btn').innerText = "🎙";
    const muteVideoBtn = document.getElementById('call-mute-video-btn'); if (muteVideoBtn) { muteVideoBtn.classList.remove('active-mode'); muteVideoBtn.innerText = "🎙"; }
    const toggleCamBtn = document.getElementById('call-toggle-camera-btn'); const toggleCamLabel = document.getElementById('call-toggle-camera-label');
    if (toggleCamBtn) { toggleCamBtn.classList.remove('active-mode'); toggleCamBtn.innerText = "📷"; }
    if (toggleCamLabel) toggleCamLabel.innerText = "O‘chirish";
    hideCallEmojiCode();
    isCallMinimized = false;
    const existingBubble = document.getElementById('call-minimized-bubble'); if (existingBubble) existingBubble.style.display = 'none';

    if (direction === 'outgoing') { callStatus.innerText = isGroup ? "Ulanmoqda ••" : "So‘rov yuborilmoqda ••"; if (acceptBox) acceptBox.style.display = 'none'; }
    else { callStatus.innerText = isGroup ? "Guruh qo'ng'irog'i keldi..." : "Sizga qo‘ng‘iroq kelmoqda..."; if (acceptBox) acceptBox.style.display = 'flex'; }

    callOverlay.style.display = 'flex';
}

function startSecondsTimer() {
    if (callTimer) clearInterval(callTimer); callSeconds = 0; const callStatus = document.getElementById('call-status');
    callTimer = setInterval(() => { callSeconds++; let mins = Math.floor(callSeconds / 60).toString().padStart(2, '0'); let secs = (callSeconds % 60).toString().padStart(2, '0'); if (callStatus) callStatus.innerText = `📶 ${mins}:${secs}`; }, 1000);
}

function toggleMute() {
    if (!localStream) return; isMuted = !isMuted; localStream.getAudioTracks().forEach(track => { track.enabled = !isMuted; });
    const muteBtn = document.getElementById('call-mute-btn'); const muteVideoBtn = document.getElementById('call-mute-video-btn');
    [muteBtn, muteVideoBtn].forEach(function(btn) { if (!btn) return; if (isMuted) { btn.classList.add('active-mode'); btn.innerText = "🔇"; } else { btn.classList.remove('active-mode'); btn.innerText = "🎙"; } });
}

function toggleSpeaker() {
    isSpeakerOn = !isSpeakerOn;
    const speakerBtn = document.getElementById('call-speaker-btn'); const videoSpeakerBtn = document.getElementById('call-video-speaker-btn');
    [speakerBtn, videoSpeakerBtn].forEach(function(btn) { if (!btn) return; if (isSpeakerOn) btn.classList.add('active-mode'); else btn.classList.remove('active-mode'); });
    if (remoteGainNode) remoteGainNode.gain.value = isSpeakerOn ? 2.2 : 1.0;
}

function playRingtone() { const ringtone = document.getElementById('call-ringtone'); if (ringtone) { ringtone.currentTime = 0; ringtone.play().catch(e => {}); } }
function stopRingtone() { const ringtone = document.getElementById('call-ringtone'); if (ringtone) ringtone.pause(); }

function hangUpCall() {
    if (currentCallPeer) socket.emit('call:end', { from: myUsername, to: currentCallPeer });
    if (window._pendingGroupCallInviter) { socket.emit('call:end', { from: myUsername, to: window._pendingGroupCallInviter }); window._pendingGroupCallInviter = null; }
    closeCallWindow();
}

function closeCallWindow() {
    const callOverlay = document.getElementById('tg-call-overlay'); if (callOverlay) { callOverlay.style.display = 'none'; callOverlay.classList.remove('ui-hidden'); }
    const bubble = document.getElementById('call-minimized-bubble'); if (bubble) bubble.style.display = 'none';
    const videoContainer = document.getElementById('call-video-container'); if (videoContainer) videoContainer.style.display = 'none';
    isCallMinimized = false; isCallActive = false;
    hideCallEmojiCode();
    if (callTimer) { clearInterval(callTimer); callTimer = null; }
    stopRingtone();
    if (peerConnection) { peerConnection.close(); peerConnection = null; }
    if (localStream) { localStream.getTracks().forEach(track => track.stop()); localStream = null; }
    if (remoteMediaStream) { remoteMediaStream.getTracks().forEach(t => t.stop()); remoteMediaStream = null; }
    if (audioCtx) { audioCtx.close(); audioCtx = null; remoteGainNode = null; }
    currentCallPeer = null; currentCallDirection = null;
}
