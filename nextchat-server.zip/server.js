// =========================================================================
// NEXTCHAT SERVER - Express + Socket.IO + JSON fayl bazasi
// =========================================================================
const express = require('express');
const http = require('http');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const cors = require('cors');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

const DATA_FILE = path.join(__dirname, 'data', 'db.json');
const UPLOADS_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });
if (!fs.existsSync(path.dirname(DATA_FILE))) fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });

// ---- ODDIY JSON FAYL BAZASI ----
function loadDb() {
    if (!fs.existsSync(DATA_FILE)) {
        return { users: {}, deviceAccounts: {}, contacts: {}, groups: [], messages: [] };
    }
    try {
        return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    } catch (e) {
        return { users: {}, deviceAccounts: {}, contacts: {}, groups: [], messages: [] };
    }
}
function saveDb(db) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}
let db = loadDb();

app.use(cors());
app.use(express.json({ limit: '15mb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(UPLOADS_DIR));

// ---- FAYL YUKLASH (rasm/video/musiqa/ovozli/dumaloq video) ----
const storage = multer.diskStorage({
    destination: function (req, file, cb) { cb(null, UPLOADS_DIR); },
    filename: function (req, file, cb) {
        let ext = path.extname(file.originalname) || '';
        cb(null, 'f_' + Date.now() + '_' + Math.round(Math.random() * 1e9) + ext);
    }
});
const upload = multer({ storage: storage, limits: { fileSize: 25 * 1024 * 1024 } });

app.post('/api/upload', upload.single('file'), function (req, res) {
    if (!req.file) return res.status(400).json({ error: 'Fayl topilmadi' });
    res.json({ url: '/uploads/' + req.file.filename, fileName: req.file.originalname });
});

// =========================================================================
// AUTH VA AKKAUNTLAR (qurilma boshiga maksimal 3 ta akkaunt)
// =========================================================================
app.post('/api/register', function (req, res) {
    let { username, password, deviceId } = req.body;
    if (!username || !password || !deviceId) return res.status(400).json({ error: "Ma'lumotlar to'liq emas" });
    username = '@' + String(username).toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (db.users[username]) return res.status(409).json({ error: "Bu username band!" });

    let devAccounts = db.deviceAccounts[deviceId] || [];
    if (devAccounts.length >= 3) return res.status(403).json({ error: "Bu qurilmada faqat 3 ta akkaunt yaratish mumkin!" });

    db.users[username] = { password: password, createdAt: Date.now() };
    devAccounts.push(username);
    db.deviceAccounts[deviceId] = devAccounts;
    db.contacts[username] = db.contacts[username] || [];
    saveDb(db);
    res.json({ success: true, username: username });
});

app.post('/api/login', function (req, res) {
    let { username, password } = req.body;
    username = '@' + String(username).toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (!db.users[username] || db.users[username].password !== password) {
        return res.status(401).json({ error: "Username yoki parol noto'g'ri!" });
    }
    res.json({ success: true, username: username });
});

app.get('/api/users/search', function (req, res) {
    let q = String(req.query.q || '').toLowerCase();
    let me = req.query.me;
    let results = Object.keys(db.users).filter(u => u.includes(q) && u !== me);
    res.json({ users: results });
});

// =========================================================================
// KONTAKTLAR
// =========================================================================
app.post('/api/contacts/add', function (req, res) {
    let { me, target } = req.body;
    if (!db.users[target]) return res.status(404).json({ error: "Foydalanuvchi topilmadi" });
    db.contacts[me] = db.contacts[me] || [];
    db.contacts[target] = db.contacts[target] || [];
    if (!db.contacts[me].includes(target)) db.contacts[me].push(target);
    if (!db.contacts[target].includes(me)) db.contacts[target].push(me);
    saveDb(db);
    res.json({ success: true });
});

app.get('/api/contacts/:username', function (req, res) {
    res.json({ contacts: db.contacts[req.params.username] || [] });
});

// =========================================================================
// GURUHLAR
// =========================================================================
app.post('/api/groups/create', function (req, res) {
    let { name, creator, members } = req.body;
    if (!name || !creator) return res.status(400).json({ error: "Ma'lumot yetarli emas" });
    let group = {
        id: 'grp_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        name: name,
        creator: creator,
        members: Array.from(new Set([creator].concat(members || []))),
        createdAt: Date.now()
    };
    db.groups.push(group);
    saveDb(db);
    group.members.forEach(m => io.to('user:' + m).emit('groups:updated'));
    res.json({ group: group });
});

app.post('/api/groups/:id/add-members', function (req, res) {
    let g = db.groups.find(x => x.id === req.params.id);
    if (!g) return res.status(404).json({ error: "Guruh topilmadi" });
    (req.body.members || []).forEach(m => { if (!g.members.includes(m)) g.members.push(m); });
    saveDb(db);
    g.members.forEach(m => io.to('user:' + m).emit('groups:updated'));
    res.json({ group: g });
});

app.post('/api/groups/:id/leave', function (req, res) {
    let idx = db.groups.findIndex(x => x.id === req.params.id);
    if (idx === -1) return res.json({ success: true });
    let g = db.groups[idx];
    g.members = g.members.filter(m => m !== req.body.username);
    let remaining = g.members.slice();
    if (g.members.length === 0) db.groups.splice(idx, 1);
    saveDb(db);
    remaining.forEach(m => io.to('user:' + m).emit('groups:updated'));
    res.json({ success: true });
});

app.get('/api/groups/for/:username', function (req, res) {
    res.json({ groups: db.groups.filter(g => g.members.includes(req.params.username)) });
});

// =========================================================================
// XABARLAR
// =========================================================================
app.get('/api/messages', function (req, res) {
    let { me, chatType, target } = req.query;
    let list = db.messages.filter(function (m) {
        if (m.deletedFor && m.deletedFor.includes(me)) return false;
        if (chatType === 'group') return m.chatType === 'group' && m.target === target;
        return m.chatType === 'private' && ((m.sender === me && m.target === target) || (m.sender === target && m.target === me));
    });
    res.json({ messages: list });
});

app.get('/api/chats/:username', function (req, res) {
    // Foydalanuvchining barcha suhbatlari uchun oxirgi xabar + unread son
    let me = req.params.username;
    let contacts = db.contacts[me] || [];
    let privateSet = new Set(contacts);
    db.messages.forEach(function (m) {
        if (m.deletedFor && m.deletedFor.includes(me)) return;
        if (m.chatType === 'private') {
            if (m.target === me) privateSet.add(m.sender);
            if (m.sender === me) privateSet.add(m.target);
        }
    });
    let chats = [];
    privateSet.forEach(function (c) {
        let related = db.messages.filter(m => !((m.deletedFor || []).includes(me)) && m.chatType === 'private' && ((m.sender === me && m.target === c) || (m.sender === c && m.target === me)));
        related.sort((a, b) => a.timestamp - b.timestamp);
        let last = related[related.length - 1];
        let unread = related.filter(m => m.sender === c && m.target === me && !m.isRead).length;
        chats.push({ type: 'private', id: c, title: c, last: last || null, unread: unread });
    });
    db.groups.filter(g => g.members.includes(me)).forEach(function (g) {
        let related = db.messages.filter(m => !((m.deletedFor || []).includes(me)) && m.chatType === 'group' && m.target === g.id);
        related.sort((a, b) => a.timestamp - b.timestamp);
        let last = related[related.length - 1];
        let unread = related.filter(m => m.sender !== me && !m.isRead).length;
        chats.push({ type: 'group', id: g.id, title: g.name, last: last || null, unread: unread, createdAt: g.createdAt });
    });
    res.json({ chats: chats });
});

app.post('/api/messages/read', function (req, res) {
    let { me, chatType, target } = req.body;
    db.messages.forEach(function (m) {
        if (chatType === 'group' && m.chatType === 'group' && m.target === target && m.sender !== me) m.isRead = true;
        if (chatType === 'private' && m.chatType === 'private' && m.sender === target && m.target === me) m.isRead = true;
    });
    saveDb(db);
    io.to('user:' + target).emit('messages:read', { by: me, chatType, target: me });
    res.json({ success: true });
});

app.post('/api/messages/delete', function (req, res) {
    let { msgId, username, deleteBoth } = req.body;
    let idx = db.messages.findIndex(m => m.id === msgId);
    if (idx === -1) return res.json({ success: true });
    let msg = db.messages[idx];
    if (deleteBoth && msg.sender === username && msg.chatType === 'private') {
        db.messages.splice(idx, 1);
        io.to('user:' + msg.target).emit('message:deleted', { id: msgId });
    } else {
        msg.deletedFor = msg.deletedFor || [];
        if (!msg.deletedFor.includes(username)) msg.deletedFor.push(username);
    }
    saveDb(db);
    res.json({ success: true });
});

app.post('/api/chats/delete', function (req, res) {
    let { username, chatType, target, deleteBoth } = req.body;
    if (chatType === 'group') {
        db.messages.forEach(function (m) {
            if (m.chatType === 'group' && m.target === target) {
                m.deletedFor = m.deletedFor || [];
                if (!m.deletedFor.includes(username)) m.deletedFor.push(username);
            }
        });
    } else {
        if (deleteBoth) {
            db.messages = db.messages.filter(m => !(m.chatType === 'private' && ((m.sender === username && m.target === target) || (m.sender === target && m.target === username))));
        } else {
            db.messages.forEach(function (m) {
                if (m.chatType === 'private' && ((m.sender === username && m.target === target) || (m.sender === target && m.target === username))) {
                    m.deletedFor = m.deletedFor || [];
                    if (!m.deletedFor.includes(username)) m.deletedFor.push(username);
                }
            });
        }
        db.contacts[username] = (db.contacts[username] || []).filter(c => c !== target);
        if (deleteBoth) db.contacts[target] = (db.contacts[target] || []).filter(c => c !== username);
    }
    saveDb(db);
    res.json({ success: true });
});

// =========================================================================
// SOCKET.IO - REAL VAQTLI XABARLAR VA QO'NG'IROQ SIGNALING
// =========================================================================
io.on('connection', function (socket) {
    let myUser = null;

    socket.on('identify', function (username) {
        myUser = username;
        socket.join('user:' + username);
    });

    socket.on('message:send', function (msg) {
        msg.id = 'msg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
        msg.timestamp = Date.now();
        let now = new Date();
        msg.timeStr = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
        msg.isRead = false;
        msg.deletedFor = [];
        db.messages.push(msg);
        saveDb(db);

        if (msg.chatType === 'private') {
            io.to('user:' + msg.target).emit('message:new', msg);
            socket.emit('message:new', msg);
        } else {
            let g = db.groups.find(x => x.id === msg.target);
            if (g) g.members.forEach(m => io.to('user:' + m).emit('message:new', msg));
        }
    });

    // ---- QO'NG'IROQ SIGNALING (WebRTC) ----
    socket.on('call:invite', function (data) {
        // data: {from, to, type, isGroup, groupId, groupName, members}
        if (data.isGroup) {
            (data.members || []).forEach(m => io.to('user:' + m).emit('call:incoming', data));
        } else {
            io.to('user:' + data.to).emit('call:incoming', data);
        }
    });
    socket.on('call:accept', function (data) { io.to('user:' + data.to).emit('call:accepted', data); });
    socket.on('call:reject', function (data) { io.to('user:' + data.to).emit('call:rejected', data); });
    socket.on('call:offer', function (data) { io.to('user:' + data.to).emit('call:offer', data); });
    socket.on('call:answer', function (data) { io.to('user:' + data.to).emit('call:answer', data); });
    socket.on('call:ice', function (data) { io.to('user:' + data.to).emit('call:ice', data); });
    socket.on('call:end', function (data) { io.to('user:' + data.to).emit('call:ended', data); });

    socket.on('disconnect', function () {});
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, function () {
    console.log('NextChat server ' + PORT + '-portda ishga tushdi');
});
